package U9.ENTREGABLE_20_21;

public class main {
  public static void main(String[] args) {

    Consultas c = new Consultas();

    c.FiltroPrecio();

    c.InfoPagos();

    c.informeCategoria();

    Transacciones t = new Transacciones();

    t.nuevoempleadoyclientes();

    t.inserofiytrasl();

  }
}
