package U9.EXAMEN_2021.EJ4;

public class main {

  public static void main(String[] args) {

      Transacciones.insertarLineaProducto();

      ConexionBD.close();

  }
}
