package U9.EXAMEN_2021.EJ1;

public class main {

  public static void main(String[] args) {

     ModificacionDOM.parsear();
     ModificacionDOM.anadirPiloto();
     ModificacionDOM.imprimir();
     ModificacionDOM.insertarPaisPiloto();
     ModificacionDOM.imprimir();

  }
}
