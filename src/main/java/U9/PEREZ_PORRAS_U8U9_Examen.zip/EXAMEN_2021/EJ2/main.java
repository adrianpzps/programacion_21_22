package U9.EXAMEN_2021.EJ2;

public class main {

  public static void main(String[] args) {

    RecorridoStax.pilotoMasCampeonatos();
    RecorridoStax.mostrarPilPorEsc("Ferrari");

  }

}
