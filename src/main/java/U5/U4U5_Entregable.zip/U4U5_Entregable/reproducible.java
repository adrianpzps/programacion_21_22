package U5.U4U5_Entregable;

public interface reproducible {

    public void play();
    public void pause();
    public void stop();

}
